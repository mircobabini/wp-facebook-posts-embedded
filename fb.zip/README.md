# Facebook Posts Embedded
Just use the shortcode [fb_embed_post uri="http://facebook.com/.."/] or use the facebook button placed in the page/post editor!
-----------------------

### Overview

Permits to add embedded posts from Facebook almost everywhere

### Installation

Install it like any other wordpress plugins.

**Install as Plugin**

Copy the 'wp-facebook-posts-embedded' folder into your plugins folder or simply upload the archive
Activate the plugin via the Plugins Admin Page
